// DLLTest.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "DLLTest.h"
#include <stdio.h>
#include <windows.h>

int _stdcall test1()
{
	char str[80];
	/*
	Get's the current process id to display in the message box
	*/
	int id = GetCurrentProcessId();
	sprintf_s(str, "Hello, process: %d", id);
	MessageBox(NULL, str, "Hello DLL!", MB_OK);
	return 0;
}

