#pragma once

extern "C" _declspec(dllexport) int _stdcall test1();